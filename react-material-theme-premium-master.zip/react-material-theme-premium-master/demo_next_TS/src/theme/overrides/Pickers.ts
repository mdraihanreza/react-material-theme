import { Theme } from '@mui/material/styles';

// ----------------------------------------------------------------------

export default function Pickers(theme: Theme) {
  return {};
}
